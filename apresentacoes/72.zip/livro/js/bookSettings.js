// paginas do livro
flippingBook.pages = [ 
	"pages/1.jpg",
	"pages/2.jpg",
	"pages/3.jpg",
	"pages/4.jpg",
	"pages/5.jpg",
	"pages/6.jpg",
	"pages/7.jpg",
	"pages/8.jpg",
	"pages/9.jpg",
	"pages/10.jpg",
	"pages/11.jpg",		"pages/12.jpg",
	"pages/13.jpg",
	"pages/14.jpg",
	"pages/15.jpg",
	"pages/16.jpg",
	"pages/17.jpg",
	"pages/18.jpg",		"pages/19.jpg", 		"pages/20.jpg",		"pages/21.jpg",		"pages/22.jpg",
	"pages/23.jpg",
	"pages/24.jpg",
	"pages/25.jpg",
	"pages/26.jpg",
	"pages/27.jpg",
	"pages/28.jpg",
	"pages/29.jpg",
	"pages/30.jpg",
	"pages/31.jpg",
	"pages/32.jpg",
	"pages/33.jpg",
	"pages/34.jpg",
	"pages/36.jpg",
	"pages/37.jpg",		"pages/38.jpg",
	"pages/39.jpg",
	"pages/40.jpg",
	"pages/41.jpg",
	"pages/42.jpg",
	"pages/43.jpg",
	"pages/44.jpg",
	"pages/46.jpg",
	"pages/47.jpg",		"pages/48.jpg",
	"pages/49.jpg",
	"pages/50.jpg",		"pages/51.jpg",	
	"pages/52.jpg",
	"pages/53.jpg",
	"pages/54.jpg",
	"pages/54.jpg",
	"pages/55.jpg",
	"pages/56.jpg",
	"pages/57.jpg",		"pages/58.jpg",		"pages/59.jpg"	
];
// configurações do livro
flippingBook.settings.preloaderType = "Gradient Wheel";//Ao abrir uma pagina carregar logo a seguinte
flippingBook.settings.backgroundImage = "img/fundo.gif";//imagem de fundo do site
flippingBook.settings.backgroundImagePlacement = "top left";// imagem de fundo alinhada
flippingBook.settings.bookWidth = 846; // largura com duas paginas juntasflippingBook.settings.bookHeight = 506; //altura
flippingBook.settings.pageBackgroundColor = 0xe71b24;
flippingBook.settings.backgroundColor = 0x000000;
flippingBook.settings.useCustomCursors = true;
flippingBook.settings.dropShadowEnabled = true,
flippingBook.settings.flipSound = "sounds/02.mp3";
flippingBook.settings.flipCornerStyle = "first page only"; // a 1º folha mexe se sozinha
flippingBook.create();
