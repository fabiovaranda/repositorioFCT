function FlippingBook() {
	this.pages = [];
	this.contents = [];

	this.stageWidth = "100%";
	this.stageHeight = "70%";
	
	this.settings = {
			bookWidth: 846,
			bookHeight: 506,
			pagesSet: this.pages,
			scaleContent: true,
			preserveProportions: false,
			centerContent: true,
			hardcover: false,
			hardcoverThickness: 3,
			hardcoverEdgeColor: 0xFFFFFF,
			highlightHardcover: true,
			frameWidth: 0,
			frameColor: 0xFFFFFF,
			frameAlpha: 100,
			firstPageNumber: 1,
			autoFlipSize: 40,
			navigationFlipOffset: 30,
			flipOnClick: true,
			handOverCorner: true,
			handOverPage: true,
			alwaysOpened: false,
			staticShadowsType: "Asymmetric", // Asymmetric, Symmetric, Default
			staticShadowsDepth: 1, // sombras do livro
			staticShadowsLightColor: 0xFFFFFF, // works for "Symmetric" shadows only
			staticShadowsDarkColor: 0x000000,
			dynamicShadowsDepth: 1, //sombra do livro ao virar a pagina
			dynamicShadowsLightColor: 0xFFFFFF, // works for "dark" pages only
			dynamicShadowsDarkColor: 0x000000,
			moveSpeed: 5, //velocidade ao virar a pagina
			closeSpeed: 3, // velocidade ao fechar
			gotoSpeed: 3,
			rigidPageSpeed: 5,
			flipSound: "",
			hardcoverSound: "",
			preloaderType: "Thin", // "Progress Bar", "Round", "Thin", "Dots", "Gradient Wheel", "Gear Wheel", "Line", "Animated Book", "None"
			pageBackgroundColor: 0xffffff,
			loadOnDemand: true, //loading do livro
			allowPagesUnload: true,
			showUnderlyingPages: false,
			playOnDemand: false, //torna a pagina invisivel ou nao quando se vira a pagina
			freezeOnFlip: false,
			darkPages: false,
			smoothPages: false,
			rigidPages: false, //forma de virar a pagina
			flipCornerStyle: "manually",// "first page only", "each page", "manually"
			flipCornerPosition: "bottom-right",// "bottom-right","top-right","bottom-left","top-left"
			flipCornerAmount: 50,
			flipCornerAngle: 20,
			flipCornerRelease: true,
			flipCornerVibrate: true,
			flipCornerPlaySound: false, // false - so faz som quando se muda a pagina or true faz sempre som
			centerBook: true, // define se o livro � no centro ou n�o
			dropShadowHideWhenFlipping: true,
			backgroundColor: 0xFFFFFF,
			backgroundImage: "img/bookBackground.jpg",
			backgroundImagePlacement: "fit", //  "top left", "center", "fit"
			extXML: ""
		};
		
		this.containerId = "fbContainer";
		this.forwardButtonId = "fbForwardButton";
		this.backButtonId = "fbBackButton";
		this.currentPagesId = "fbCurrentPages";
		this.totalPagesId = "fbTotalPages";
		this.contentsMenuId = "fbContentsMenu";
};

FlippingBook.prototype.create = function(){
	this.settings.pagesSet = this.pages;
	if( location.hash.substr(1) != "" )
		this.settings.firstPageNumber = location.hash.substr(1);
	
	this.addLoadEvent( this.onWindowLoad );
	swfobject.embedSWF("FlippingBook.swf", this.containerId, this.stageWidth, this.stageHeight, "8.0.0", "js/expressInstall.swf", this.settings, {allowScriptAccess: "always", bgcolor:  "#" + this.settings.backgroundColor.toString( 16 ) });
}

FlippingBook.prototype.getFlippingBookReference = function() {
	return this.getObjectReference( this.containerId );
}

FlippingBook.prototype.getObjectReference = function( id ) {
	return document.getElementById( id );
}
FlippingBook.prototype.flipForward = function() {
	flippingBook.getFlippingBookReference().flipForward();
}

FlippingBook.prototype.flipBack = function() {
	flippingBook.getFlippingBookReference().flipBack();
}
FlippingBook.prototype.onWindowLoad = function(){	
	var forwardButton = flippingBook.getObjectReference( flippingBook.forwardButtonId );
	if( forwardButton ){
		forwardButton.style.cursor = "pointer";
		forwardButton.onclick = flippingBook.flipForward;
	}
	
	var backButton = flippingBook.getObjectReference( flippingBook.backButtonId );
	if( backButton ){
		backButton.style.cursor = "pointer";
		backButton.onclick = flippingBook.flipBack;
	}
        
	flippingBook.buildContentsMenu();
}

FlippingBook.prototype.onPutPage = function( leftPageNumber, rightPageNumber ){
	this.updatePagination( leftPageNumber, rightPageNumber );
	this.updateContentsMenu( leftPageNumber, rightPageNumber );
}

FlippingBook.prototype.updatePagination = function( leftPageNumber, rightPageNumber ){
	var leftPageExists = ( leftPageNumber != undefined );
	var rightPageExists = ( rightPageNumber != undefined );
			
	var pageNumberString = leftPageNumber + "-" + rightPageNumber;
	if( !leftPageExists )
		pageNumberString = rightPageNumber;	
	if( !rightPageExists )
		pageNumberString = leftPageNumber;

	this.getObjectReference( this.currentPagesId ).innerHTML = pageNumberString;
	this.getObjectReference( this.totalPagesId ).innerHTML = " / " + this.getFlippingBookReference().totalPages();	
}

FlippingBook.prototype.buildContentsMenu = function(){
	var contentsSelect = this.getObjectReference( this.contentsMenuId );
	
	if( contentsSelect ){
		for( var i = 0; i < this.contents.length; i++ )
			contentsSelect.options[i] = new Option(this.contents[i][0], this.contents[i][1]);
			
		contentsSelect.onchange = this.onContentsChange;
	}
}

FlippingBook.prototype.onContentsChange = function(){
	var contentsSelect = flippingBook.getObjectReference( flippingBook.contentsMenuId );
	var pageNumber = contentsSelect.options[contentsSelect.selectedIndex].value;
	
	if( pageNumber )
		flippingBook.getFlippingBookReference().flipGotoPage( pageNumber );
}

FlippingBook.prototype.updateContentsMenu = function( leftPageNumber, rightPageNumber ){
	var contentsSelect = flippingBook.getObjectReference( flippingBook.contentsMenuId );

	if( contentsSelect ){
		for( var i = 0; i < this.contents.length - 1; i++ ){
			var minPage = contentsSelect.options[i].value;
			var maxPage = contentsSelect.options[i+1].value;
			var leftOK = false;
			var rightOK = false;
			
			if( leftPageNumber )
				leftOK = ( Number( leftPageNumber ) >=  minPage && Number( leftPageNumber ) <= maxPage );
			else
				leftOK = true;

			if( rightPageNumber )
				rightOK = ( Number( rightPageNumber ) >=  minPage && Number( rightPageNumber ) <= maxPage );
			else
				rightOK = true;
				
			if( leftOK && rightOK )	
				break;
		}	
		contentsSelect.selectedIndex = i;
	}
}

FlippingBook.prototype.getWindowHeight = function() {
	var windowHeight = 0;
	
	if (typeof(window.innerHeight) == 'number' ) {
		windowHeight=window.innerHeight;
	}
	else {
		if (document.documentElement &&	document.documentElement.clientHeight) {
				windowHeight = document.documentElement.clientHeight;
		}
		else {
			if (document.body&&document.body.clientHeight) {
				windowHeight=document.body.clientHeight;
			}
		}
	}
	
	return windowHeight;
}

FlippingBook.prototype.addLoadEvent = function ( fn ) {
	if (typeof window.addEventListener != "undefined") {
		window.addEventListener("load", fn, false);
	}
	else if (typeof document.addEventListener != "undefined") {
		document.addEventListener("load", fn, false);
	}
	else if (typeof window.attachEvent != "undefined") {
		window.attachEvent("onload", fn);
	}
	else if (typeof window.onload == "function") {
		var fnOld = window.onload;
		window.onload = function() {
			fnOld();
			fn();
		};
	}
	else {
		window.onload = fn;
	}
}

FlippingBook.prototype.handleWheel = function ( delta ){
	this.getFlippingBookReference().onWheelScroll( delta );
}

flippingBook = new FlippingBook();

function wheel(event){
	var delta = 0;
	if (!event) event = window.event;
	if (event.wheelDelta) {
		delta = event.wheelDelta/120; 
		if (window.opera) delta = -delta;
	} else if (event.detail) {
		delta = -event.detail/3;
	}
	if (delta)
		flippingBook.handleWheel(delta);
        if (event.preventDefault)
                event.preventDefault();
        event.returnValue = false;
}

if (window.addEventListener)
	window.addEventListener('DOMMouseScroll', wheel, false);
window.onmousewheel = document.onmousewheel = wheel;